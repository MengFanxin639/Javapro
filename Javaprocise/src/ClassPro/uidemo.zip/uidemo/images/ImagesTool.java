package ClassPro.uidemo.images;

import java.awt.Image;

import javax.swing.ImageIcon;

public class ImagesTool {
	public static final ImageIcon icon = new ImageIcon("D:/javatext/Javaprocise/src/ClassPro/uidemo/images/icon.jpg");
	public static final Image iconn = icon.getImage();
	
	public static final ImageIcon face = new ImageIcon("D:/javatext/Javaprocise/src/ClassPro/uidemo/images/face.jpg");
	public static final Image iface = face.getImage();
	
	
}
