package ClassPro.uidemo.GoodsDemoFrame;

import java.awt.event.*;
import javax.swing.*;

import ClassPro.uidemo.images.ImagesTool;

public class GoodsDemoFrame extends JFrame{

	public static double price;
	public static int count;
	
	//�������
	private JPanel jPanel= null;
	private JLabel jLabel1 = null;
	private JLabel jLabel12 = null;
	private JLabel jLabel13 = null;
	private JTextField jTextField1 = null;
	private JTextField jTextField2 = null;
	private JTextField jTextField3 = null;
	private JButton jButton = null;
	
	public GoodsDemoFrame() {
		initFrame();
		this.setSize(270 , 300);
		this.setTitle("���Ѱ�������ʾ");
		this.setIconImage(ImagesTool.iface);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private void initFrame() {
		//�������
		jPanel = new JPanel();
		jLabel1 = new JLabel("��Ʒ����");
		jLabel12 = new JLabel("��Ʒ����");
		jLabel13 = new JLabel("���ѽ��");
		jTextField1 = new JTextField(15);
		jTextField2 = new JTextField(15);
		jTextField3 = new JTextField(15);
		jButton = new JButton("����");
		jTextField3.setEditable(false);
		//�������
		jPanel.add(jLabel1);
		jPanel.add(jTextField1);
		jPanel.add(jLabel12);
		jPanel.add(jTextField2);
		jPanel.add(jLabel13);
		jPanel.add(jTextField3);
		jPanel.add(jButton);
		//�������
		this.setContentPane(jPanel);	
		
		//�����¼�����
		/**
		 * ��Ʒ����
		 */
		jTextField1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String text = jTextField1.getText();
				if (hasChar(jTextField1)) {
					JOptionPane.showMessageDialog(null, "�����ʽ����");
					jTextField1.setText("");
				}
				double price = Double.parseDouble(text);
				GoodsDemoFrame.price = price;
			}
		});
		
		/**
		 * ��Ʒ����
		 */
		jTextField2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String text = jTextField2.getText();
				if (hasChar(jTextField2)) {
					JOptionPane.showMessageDialog(null, "�����ʽ����");
					jTextField1.setText("");
				}
				int count = Integer.parseInt(text);
				GoodsDemoFrame.count = count;
			}
		});
		
		
		jButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				double cost = GoodsDemoFrame.price * GoodsDemoFrame.count;
				jTextField3.setText(String.valueOf(cost) + "��");
				
			}
		});
	}
	
	
	
	
	/**
	 * �ı��������Ƿ�ֻ��������
	 * @return�����ַ�����true
	 */
	private boolean hasChar(JTextField jTextField) {
		String text = jTextField.getText();
		for (int i = 0; i < text.length(); i++) {
			if (!(Character.isDigit(text.charAt(i)))) {
				return true;
			}
		}
		return false;
	}


	public static void main(String[] args) {
		new GoodsDemoFrame();
	}
}
