package ClassPro.uidemo.studentidui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import ClassPro.uidemo.images.ImagesTool;

/**
 * ѧ���򵥽������ʾ��ҵ
 * @version 1.0
 * @author С����
 * @2018��11��27�� ����12:32:53
 */
public class StudentIdFrame extends JFrame{

	private JPanel jPanel = null;
	private JLabel text1 = null;
	private JLabel text2 = null;
	private JTextField jField1 = null;
	private JTextField jField2 = null;
	private JButton jbClear = null;
	private JButton jbCopy = null;
	
	public StudentIdFrame() {
		init();
		this.setTitle("����ѧ��");
		this.setIconImage(ImagesTool.iconn);
		this.setVisible(true);
		this.setSize(260,290);
		this.setLocationRelativeTo(null);
//		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private void init() {
		jPanel = new JPanel();
		text1 = new JLabel("�ı�1");
		text2 = new JLabel("�ı�2");
		jField1 = new JTextField("JAVA", 15);
		jField2 = new JTextField("JAVA",15);
		jbClear = new JButton("���");
		jbCopy = new JButton("����");
		
		
		jPanel.add(text1);
		jPanel.add(jField1);
		jPanel.add(text2);
		
		jPanel.add(jField2);
		jPanel.add(jbClear);
		jPanel.add(jbCopy);
		this.setContentPane(jPanel);
	}
	
	
	
	public static void main(String[] args) {
		new StudentIdFrame();
	}

}
